{{config(materialized='incremental',unique_key='invoiceid') }}

with fact_invoiceline as(
    select *,
    '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
     from {{ source('stg', 'invoiceline') }}
)
select 
invoiceid,
invoicelineid,
trackid,
unitprice,
quantity,
last_update,
dbt_time
from fact_invoiceline