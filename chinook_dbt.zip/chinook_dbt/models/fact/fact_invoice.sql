{{config(materialized='incremental',unique_key='invoiceid') }}

with  fact_invoice as(
    select *,
    '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
     from {{ source('stg', 'invoice') }}

)
select 
invoiceid,
customerid,
invoicedate,
billingaddress,
billingcity,
billingstate,
billingcountry,
billingpostalcode,
total,
last_update,
dbt_time
from fact_invoice