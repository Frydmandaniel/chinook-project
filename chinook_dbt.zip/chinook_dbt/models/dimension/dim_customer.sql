
{{ config(materialized='table') }}

WITH normalized_data AS (
    SELECT
        *,
        UPPER(SUBSTRING(firstname FROM 1 FOR 1)) || LOWER(SUBSTRING(firstname FROM 2)) AS first_name,
        UPPER(SUBSTRING(lastname FROM 1 FOR 1)) || LOWER(SUBSTRING(lastname FROM 2)) AS last_name,
        substring(email from POSITION('@' in email)+1 for char_length(email)-POSITION('@' in email)) as domain,
         '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
    FROM
        {{ source('stg', 'customer') }} as customer)

SELECT
    customerid,
    first_name,
    last_name,
    company,
    address,
    city,
    state,
    country,
    phone,
    domain,
    supportrepid,
    last_update,
    dbt_time

FROM
    normalized_data
