{{ config(materialized='table') }}

with track as (
    select *,name as track_name,
             extract(EPOCH FROM to_timestamp(milliseconds / 1000.0)) as seconds_duration,
             to_char(to_timestamp(track.milliseconds / 1000.0), 'MI:SS') as minutes_duration,
             '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
                 from{{ source('stg', 'track') }} as track),
    album as (
        select *
         from{{ source('stg', 'album') }} as album),
    artist as(
        select *, name as artist_name
         from{{ source('stg', 'artist') }} as artist),
    mediatype as(
        select *, name as mediatype_name
         from{{ source('stg', 'mediatype') }} as mediatype),
    genre as(
        select *, name as genre_name
         from{{ source('stg', 'genre') }} as genre),
    join_tables as(
        select 
         track.trackid,
         track_name,
         composer,
         bytes,
         seconds_duration,
         minutes_duration,
         unitprice,
         album.albumid,
         title,
         artist.artistid,
         artist_name,
         mediatype.mediatypeid,
         mediatype_name,
         genre.genreid,
         genre_name,
         dbt_time
        from track 
        left join album on track.albumid = album.albumid
        left join artist on album.artistid = artist.artistid
        left join mediatype on track.mediatypeid = mediatype.mediatypeid
        left join genre on track.genreid = genre.genreid
    )
    select *
    from 
    join_tables
    




    





