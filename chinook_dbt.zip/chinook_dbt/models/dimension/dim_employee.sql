{{ config(materialized='table') }}

with employee as (
    select *,
    concat(extract(year from age(last_update, hiredate)), ' years ', extract(month from age(last_update, hiredate)), ' months') AS work_time,
    substring(email from POSITION('@' in email) + 1 for char_length(email) - POSITION('@' in email)) as domain,
    '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
         from{{ source('stg', 'employee') }} as employee),
    department_budget as (
    select *
         from{{ source('stg', 'department_budget') }} as department_budget),
    customer as (
    select *
     from{{ source('stg', 'customer') }} as customer),
     join_tables_1 as(
        select *
        from employee 
        left join department_budget on employee.departmentid = department_budget.department_id),
     join_tables_2 as (
        select
         join_tables_1.*,
        (case when customerid = reportsto then 1
        else 0 end) as is_mananger
        from join_tables_1 
        left join customer on join_tables_1.reportsto = customer.customerid
     )
     select
        employeeid,
        firstname,
        lastname,
        work_time,
        title,
        reportsto,
        address,
        city,
        country,
        postalcode,
        phone,
        fax,
        email,
        domain,
        is_mananger,
        department_id,
        budget,
        last_update,
        dbt_time
     from join_tables_2
     where 1=1
    
