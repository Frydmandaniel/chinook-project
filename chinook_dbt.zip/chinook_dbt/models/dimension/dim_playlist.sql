{{ config(materialized='table') }}

with playlist as (
                SELECT *
                FROM
        {{ source('stg', 'playlist') }} as playlist),
playlisttrack as (
    select * from {{ source('stg', 'playlisttrack') }}
  )
  select 
  playlist.playlistid,
  name,
  trackid,
  playlist.last_update,
  '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
  from playlist 
  left join playlisttrack on playlist.playlistid = playlisttrack.playlistid

