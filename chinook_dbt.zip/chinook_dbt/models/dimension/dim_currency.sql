{{ config(materialized='table') }}

with currency as (
                SELECT *
                FROM
        {{ source('stg', 'currency') }} as currency)
  select 
  currency_id,
  date,
  exchange_rate,
  currency,
  '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
  from currency
