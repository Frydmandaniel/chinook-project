import numpy as np
import pandas.core.frame
from numpy.random import randn
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import missingno as ms
import seaborn as sns
import sqlalchemy
import json
#read the three files
delimiter_file_path = r'C:\Users\Danielf\Desktop\course_data_analyst\final project\raw-department.txt'
data_department = pd.read_csv(delimiter_file_path, delimiter='-')#, names=['department_id', 'department_name'], index_col='department_id')
#data_department['department_id'] = data_department.index.str.split('-').str[0].astype(int)
print(data_department)

file_budget = r'C:\Users\Danielf\Desktop\course_data_analyst\final project\raw-department-budget.txt'
budget = pd.read_json(file_budget,lines=True)
print(budget)

file_budget_2 = r'C:\Users\Danielf\Desktop\course_data_analyst\final project\raw-department-budget2.txt'
budget_2 = pd.read_json(file_budget_2, orient='columns')
print(budget_2)

#union
file_budget = r'C:\Users\Danielf\Desktop\course_data_analyst\final project\raw-department-budget.txt'
budget = pd.read_json(file_budget, lines=True)
file_budget_2 = r'C:\Users\Danielf\Desktop\course_data_analyst\final project\raw-department-budget2.txt'
budget_2 = pd.read_json(file_budget_2, orient='columns')
union_df_1 = pd.concat([budget, budget_2])
print(union_df_1)
#merge
merge_table = pd.merge(data_department,union_df_1, how='left', on='department_id')
total_dep = merge_table.groupby(['department_id','department_name'])['budget'].sum()
print(total_dep)

# sqlalchemy to create a table in postgresql
conn_string = 'postgresql://postgres:Aa123456@127.0.0.1/chinook'
db = sqlalchemy.create_engine(conn_string)
with db.connect() as connection:
    total_dep.to_sql('department_budget', con=connection, if_exists='replace', schema='stg')


#API to create dim_currency
import sqlalchemy
from sqlalchemy import create_engine
import json
import requests
from datetime import datetime
from forex_python.converter import CurrencyRates

c = CurrencyRates()


# Sua moeda de interesse (ILS neste caso)
target_currency = "ILS"

api_key = '2b6c303cd496b1c3d5f8674f0c86edf9'
start_date = "2018-01-01"
end_date = "2018-12-22"
base_currency = "USD"
target_currency = "ILS"

url = f"http://api.exchangeratesapi.io/v1/timeseries?access_key={api_key}&start_date={start_date}&end_date={end_date}&base={base_currency}&symbols={target_currency}"

response = requests.get(url)
data = response.json()
print(data)

api_key_5 = 'c9f24a65dba64cc9b4cc28fa5fc7845a'
base_currency_5 = "USD"
target_currency_5 = "ILS"
url_5 = f'https://open.er-api.com/v6/latest/{base_currency_5}?app_id={app_id}'
url = "https://openexchangerates.org/api/time-series.json?app_id=Required&start=Required&end=Required&symbols=Recommended&base=Optional&show_alternative=false&prettyprint=false"

import requests

url = "https://openexchangerates.org/api/time-series.json?app_id=Required&app_id=c9f24a65dba64cc9b4cc28fa5fc7845a&start=Required&end=Required&symbols=Recommended&base=Optional&show_alternative=false&prettyprint=false"

headers = {"accept": "application/json"}

response = requests.get(url, headers=headers)

print(response.text)

url = "https://openexchangerates.org/api/historical/:date.json?app_id=Required&app_id=c9f24a65dba64cc9b4cc28fa5fc7845a&base=Optional&symbols=Optional&show_alternative=false&prettyprint=false"

headers = {"accept": "application/json"}

response = requests.get(url, headers=headers)

print(response.text)

import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime, timedelta
from forex_python.converter import CurrencyRates

c = CurrencyRates()

base_currency = 'USD'
target_currency = 'ILS'
start_date = datetime(2018, 1, 1)
end_date = datetime(2022, 12, 22)

def get_exchange_rate(date):
    try:
        rate = c.get_rate(base_currency, target_currency, date)
        return rate
    except Exception as e:
        print(f"Erro ao obter taxa de câmbio: {e}")
        return None

date_list = [start_date + timedelta(days=x) for x in range((end_date - start_date).days + 1)]
exchange_rates = {date: get_exchange_rate(date) for date in date_list}

df_dim_currency = pd.DataFrame(list(exchange_rates.items()), columns=['date', 'exchange_rate'])
df_dim_currency = df_dim_currency.reset_index()  # Reiniciar os índices
df_dim_currency['currency_id'] = df_dim_currency['index'] + 1  # Adicionar 1 para começar a contar de 1
df_dim_currency['currency'] = 'ILS'  # Adicione uma coluna 'currency' com valor 'ILS'
df_dim_currency = df_dim_currency[['currency_id', 'date', 'exchange_rate', 'currency']]
print(df_dim_currency)# Reorganize as colunas
# Seu DataFrame
df_dim_currency = df
conn_string = 'postgresql://postgres:Aa123456@127.0.0.1/chinook'
table_name = 'currency'
db = sqlalchemy.create_engine(conn_string)
with db.connect() as connection:
    df.to_sql('currency', con=connection, if_exists='replace', schema='stg')
engine = create_engine(conn_string)
df_dim_currency.to_sql('currency', engine, if_exists='replace', index=False)
engine.dispose()

df_dim_currency = df
conn_string = 'postgresql://postgres:Aa123456@127.0.0.1/chinook'
db = sqlalchemy.create_engine(conn_string)
with db.connect() as connection:
    df.to_sql('currency', con=connection, if_exists='replace', schema='stg')


import pandas as pd
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, Float, Date, VARCHAR

df_dim_currency['currency'] = 'ILS'
df_dim_currency = df_dim_currency[['currency_id', 'date', 'exchange_rate', 'currency']]
df_dim_currency['currency_id'] = range(1, len(df_dim_currency) + 1)
df_dim_currency = df_dim_currency[['currency_id', 'date', 'exchange_rate', 'currency']]
conn_string = 'postgresql://postgres:Aa123456@127.0.0.1/chinook'
table_name = 'currency'
engine = create_engine(conn_string)
metadata = MetaData()
table = Table(
    table_name,
    metadata,
    Column('currency_id', Integer, primary_key=True),
    Column('date', Date, nullable=False),
    Column('exchange_rate', Float, nullable=False),
    Column('currency', VARCHAR(3), nullable=False),
    extend_existing=True
)

metadata.create_all(engine, checkfirst=True)
df_dim_currency.to_sql(table_name, engine, if_exists='replace', index=False)
engine.dispose()
